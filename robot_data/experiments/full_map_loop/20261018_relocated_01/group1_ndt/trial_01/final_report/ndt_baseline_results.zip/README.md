# 原 NDT 第 1 组实车结果

解压后打开 final_report/experiment_report.md。包含全部 PNG/SVG/PDF/CSV 和报告；843 MiB 正式原始录包留在工作区 formal_bag_01，未重复打包。
