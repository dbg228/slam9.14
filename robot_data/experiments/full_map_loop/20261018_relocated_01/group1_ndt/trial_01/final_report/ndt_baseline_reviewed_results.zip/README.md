# 原 NDT 复核版结果

先读 review_01/review_report.md，再读 final_report/experiment_report.md。原始数值保留；13 mm 短窗一致性不能概括稳定定位精度，63.74 m 原始位置累加不是独立测得的物理路程。

完整 ROS 原始录包留在工作区 formal_bag_01，未重复打包。旧压缩包也留在工作区，不包含在本包中。
